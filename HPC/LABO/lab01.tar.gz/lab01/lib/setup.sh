#!/bin/bash

STB_URL=https://github.com/nothings/stb.git  

INITIAL_DIR=$PWD

# STB
cd $INITIAL_DIR
git clone $STB_URL $STB_DIR

Here are the files related to hardware, ie VHDL source and simulation files, Quartus and Qsys project

folder structure:
    - eda: files related to the Quartus project and Qsys project
    - script: script files for compilation and simulation
    - sim: simulation files
    - src: source files
    - tb: test bench source files
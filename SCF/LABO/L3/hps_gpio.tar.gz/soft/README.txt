Here are the files related to software, ie linux files and project, Altera Monitor Program source and project files

folder structure:
    - build: all build files
    - proj: Altera Monitor Program project and generated files (didn't find a way to generate files into build folder)
    - src: source files
    - test: test files